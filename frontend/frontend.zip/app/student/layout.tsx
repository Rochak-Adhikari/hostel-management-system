import Sidebar from "@/components/Sidebar";

export default function StudentLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex h-screen overflow-hidden ...">
     <Sidebar />
      <div className="flex-1 min-w-0 p-4 sm:p-5 overflow-y-auto">{children}</div>
</div>
  );
}
